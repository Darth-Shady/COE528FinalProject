package Project;

public interface State_interface {
    double getDiscount(double total);
    int getPointsEarned(double total);
    String getStatus();
}