package Project;

import java.io.*;
import java.util.ArrayList;

public class FileManager {

    public static void loadBooks(BookStore store) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("books.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String name = parts[0];
                double price = Double.parseDouble(parts[1]);
                store.addBook(new Book(name, price));
            }

            br.close();
        } catch (IOException e) {
            System.out.println("No books file found.");
        }
    }

    public static void saveBooks(BookStore store) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("books.txt"));

            for (Book b : store.getBooks()) {
                pw.println(b.getName() + "," + b.getPrice());
            }

            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadCustomers(BookStore store) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("customers.txt"));
            String line;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                String username = parts[0];
                String password = parts[1];
                int points = Integer.parseInt(parts[2]);

                Customer c = new Customer(username, password);
                // restore points from file (do not treat as a purchase)
                c.setPoints(points);
                store.addCustomer(c);
            }

            br.close();
        } catch (IOException e) {
            System.out.println("No customers file found.");
        }
    }

    public static void saveCustomers(BookStore store) {
        try {
            PrintWriter pw = new PrintWriter(new FileWriter("customers.txt"));

            for (Customer c : store.getCustomers()) {
                pw.println(c.getUsername() + "," +
                           c.getPassword() + "," +
                           c.getPoints());
            }

            pw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}