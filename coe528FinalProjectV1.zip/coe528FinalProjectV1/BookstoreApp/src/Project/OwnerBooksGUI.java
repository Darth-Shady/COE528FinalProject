package Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class OwnerBooksGUI extends JPanel {
    private DefaultTableModel model;
    private JTable table;

    public OwnerBooksGUI(MainFrame frame, BookStore store) {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"Name", "Price"}, 0);
        table = new JTable(model);
        refreshTable(store);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JTextField nameField = new JTextField(10);
        JTextField priceField = new JTextField(5);

        JButton addBtn = new JButton("Add");
        JButton deleteBtn = new JButton("Delete");
        JButton backBtn = new JButton("Back");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Name"));
        panel.add(nameField);
        panel.add(new JLabel("Price"));
        panel.add(priceField);
        panel.add(addBtn);
        panel.add(deleteBtn);
        panel.add(backBtn);

        add(panel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            String name = nameField.getText();
            double price = Double.parseDouble(priceField.getText());
            store.addBook(new Book(name, price));
            refreshTable(store);
        });

        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String name = (String) model.getValueAt(row, 0);
                store.deleteBook(name);
                refreshTable(store);
            }
        });

        backBtn.addActionListener(e -> frame.showOwner());
    }

    private void refreshTable(BookStore store) {
        model.setRowCount(0);
        for (Book b : store.getBooks()) {
            model.addRow(new Object[]{b.getName(), b.getPrice()});
        }
    }
}