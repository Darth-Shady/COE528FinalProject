package Project;

import java.util.ArrayList;

public class BookStore {
    private ArrayList<Book> books;
    private ArrayList<Customer> customers;

    public BookStore() {
        books = new ArrayList<>();
        customers = new ArrayList<>();

        // Default admin is handled in login check
    }

    // LOGIN
    public Customer login(String username, String password) {
        if (username.equals("admin") && password.equals("admin"))
            return null; // owner login

        for (Customer c : customers) {
            if (c.getUsername().equals(username) &&
                c.getPassword().equals(password)) {
                return c;
            }
        }
        return null;
    }

    // BOOK METHODS
    public void addBook(Book b) {
        books.add(b);
    }

    public void deleteBook(String name) {
        books.removeIf(b -> b.getName().equals(name));
    }

    public ArrayList<Book> getBooks() {
        return books;
    }

    // CUSTOMER METHODS
    public void addCustomer(Customer c) {
        customers.add(c);
    }

    public void deleteCustomer(String username) {
        customers.removeIf(c -> c.getUsername().equals(username));
    }

    public ArrayList<Customer> getCustomers() {
        return customers;
    }
}