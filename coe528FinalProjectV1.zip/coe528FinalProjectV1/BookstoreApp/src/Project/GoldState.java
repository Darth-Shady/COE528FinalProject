package Project;

public class GoldState implements State_interface {

    @Override
    public double getDiscount(double total) {
        return total * 0.1; // 10% discount
    }

    @Override
    public int getPointsEarned(double total) {
        return (int)(total * 5); // Gold earns fewer points
    }

    @Override
    public String getStatus() {
        return "Gold";
    }
}