package Project;

import javax.swing.*;

public class MainFrame extends JFrame {
    private BookStore store;

   public MainFrame() {
    store = new BookStore();

    FileManager.loadBooks(store);
    FileManager.loadCustomers(store);

    setTitle("Book Store");
    setSize(600, 400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setLocationRelativeTo(null);

    showLogin();
    setVisible(true);
    
    addWindowListener(new java.awt.event.WindowAdapter() {
    public void windowClosing(java.awt.event.WindowEvent e) {
        FileManager.saveBooks(store);
        FileManager.saveCustomers(store);
    }
});
}

    public void showLogin() {
        setContentPane(new LoginGUI(this, store));
        revalidate();
    }

    public void showOwner() {
        setContentPane(new OwnerGUI(this, store));
        revalidate();
    }

    public void showOwnerBooks() {
        setContentPane(new OwnerBooksGUI(this, store));
        revalidate();
    }

    public void showOwnerCustomers() {
        setContentPane(new OwnerCustomersGUI(this, store));
        revalidate();
    }

    public void showCustomer(Customer c) {
        setContentPane(new CustomerStartGUI(this, store, c));
        revalidate();
    }
}