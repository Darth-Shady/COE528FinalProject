package Project;

import javax.swing.*;
import java.awt.*;

public class OwnerGUI extends JPanel {

    public OwnerGUI(MainFrame frame, BookStore store) {
        setLayout(new GridLayout(3, 1));

        JButton booksBtn = new JButton("Books");
        JButton customersBtn = new JButton("Customers");
        JButton logoutBtn = new JButton("Logout");

        add(booksBtn);
        add(customersBtn);
        add(logoutBtn);

        booksBtn.addActionListener(e -> frame.showOwnerBooks());
        customersBtn.addActionListener(e -> frame.showOwnerCustomers());
        logoutBtn.addActionListener(e -> frame.showLogin());
    }
}