package Project;

public class Customer {
    private String username;
    private String password;
    private int points;
    private State_interface state;

    public Customer(String username, String password) {
        this.username = username;
        this.password = password;
        this.points = 0;
        this.state = new SilverState();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
        updateState();
    }

    public String getStatus() {
        return state.getStatus();
    }

    public double buy(double total) {
        double discount = state.getDiscount(total);
        double finalPrice = total - discount;

        points += state.getPointsEarned(finalPrice);

        updateState();
        return finalPrice;
    }

    public void redeemPoints() {
        double discount = points / 100.0;
        points = 0;
    }


    // Redeem a specific number of points and return the dollar discount applied
    public double redeemPoints(int pointsToUse) {
        if (pointsToUse <= 0) return 0.0;
        if (pointsToUse > this.points) pointsToUse = this.points;
        this.points -= pointsToUse;
        updateState();
        return pointsToUse / 100.0;
    }
    private void updateState() {
        if (points >= 1000)
            state = new GoldState();
        else
            state = new SilverState();
    }
}