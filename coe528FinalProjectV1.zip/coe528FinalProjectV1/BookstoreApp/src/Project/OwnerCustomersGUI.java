package Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class OwnerCustomersGUI extends JPanel {
    private DefaultTableModel model;
    private JTable table;

    public OwnerCustomersGUI(MainFrame frame, BookStore store) {
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new Object[]{"Username", "Points", "Status"}, 0);
        table = new JTable(model);
        refreshTable(store);

        add(new JScrollPane(table), BorderLayout.CENTER);

        JTextField userField = new JTextField(10);
        JTextField passField = new JTextField(10);

        JButton addBtn = new JButton("Add");
        JButton deleteBtn = new JButton("Delete");
        JButton backBtn = new JButton("Back");

        JPanel panel = new JPanel();
        panel.add(new JLabel("Username"));
        panel.add(userField);
        panel.add(new JLabel("Password"));
        panel.add(passField);
        panel.add(addBtn);
        panel.add(deleteBtn);
        panel.add(backBtn);

        add(panel, BorderLayout.SOUTH);

        addBtn.addActionListener(e -> {
            store.addCustomer(new Customer(userField.getText(), passField.getText()));
            refreshTable(store);
        });

        deleteBtn.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) {
                String username = (String) model.getValueAt(row, 0);
                store.deleteCustomer(username);
                refreshTable(store);
            }
        });

        backBtn.addActionListener(e -> frame.showOwner());
    }

    private void refreshTable(BookStore store) {
        model.setRowCount(0);
        for (Customer c : store.getCustomers()) {
            model.addRow(new Object[]{c.getUsername(), c.getPoints(), c.getStatus()});
        }
    }
}