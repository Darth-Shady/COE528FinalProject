package Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class CustomerStartGUI extends JPanel {
    private DefaultTableModel storeModel;
    private DefaultTableModel cartModel;
    private JTable storeTable;
    private JTable cartTable;
    private JLabel totalLabel;
    private JLabel discountLabel;
    private JLabel finalLabel;
    private JLabel pointsLabel;
    private JLabel statusLabel;

    private double appliedDiscount = 0.0;
    private Customer customer;
    private BookStore store;
    private int pendingPointsToUse = 0;

    public CustomerStartGUI(MainFrame frame, BookStore store, Customer customer) {
        this.customer = customer;
        this.store = store;
        setLayout(new BorderLayout());

        storeModel = new DefaultTableModel(new Object[]{"Name", "Price"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        cartModel = new DefaultTableModel(new Object[]{"Name", "Price"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        storeTable = new JTable(storeModel);
        cartTable = new JTable(cartModel);

        refreshStoreTable(store);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                new JScrollPane(storeTable), new JScrollPane(cartTable));
        split.setResizeWeight(0.5);
        add(split, BorderLayout.CENTER);

        JPanel summary = new JPanel(new GridLayout(2, 3));
        totalLabel = new JLabel("Total: $0.00");
        discountLabel = new JLabel("Discount: $0.00");
        finalLabel = new JLabel("Final: $0.00");
        pointsLabel = new JLabel("Points: " + customer.getPoints());
        statusLabel = new JLabel("Status: " + customer.getStatus());

        summary.add(totalLabel);
        summary.add(discountLabel);
        summary.add(finalLabel);
        summary.add(pointsLabel);
        summary.add(statusLabel);

        add(summary, BorderLayout.NORTH);

        JPanel controls = new JPanel();
        JButton addToCartBtn = new JButton("Add to Cart");
        JButton removeFromCartBtn = new JButton("Remove from Cart");
        JButton redeemBtn = new JButton("Redeem Points");
        JButton checkoutBtn = new JButton("Checkout");
        JButton logoutBtn = new JButton("Logout");

        controls.add(addToCartBtn);
        controls.add(removeFromCartBtn);
        controls.add(redeemBtn);
        controls.add(checkoutBtn);
        controls.add(logoutBtn);

        add(controls, BorderLayout.SOUTH);

        addToCartBtn.addActionListener(e -> {
            int[] rows = storeTable.getSelectedRows();
            for (int r : rows) {
                String name = (String) storeModel.getValueAt(r, 0);
                Object priceObj = storeModel.getValueAt(r, 1);
                double price = (priceObj instanceof Number) ? ((Number) priceObj).doubleValue() : Double.parseDouble(priceObj.toString());
                cartModel.addRow(new Object[]{name, price});
            }
            computeTotals();
        });

        removeFromCartBtn.addActionListener(e -> {
            int[] rows = cartTable.getSelectedRows();
            for (int i = rows.length - 1; i >= 0; i--) {
                cartModel.removeRow(rows[i]);
            }
            computeTotals();
        });

        redeemBtn.addActionListener(e -> {
            if (cartModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Cart is empty");
                return;
            }
            int available = customer.getPoints();
            String input = JOptionPane.showInputDialog(this, "Enter points to redeem (max " + available + ") or leave blank to redeem all:", "", JOptionPane.PLAIN_MESSAGE);
            if (input == null) return; // cancelled
            int usePoints;
            if (input.trim().isEmpty()) {
                usePoints = available;
            } else {
                try {
                    usePoints = Integer.parseInt(input.trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(this, "Invalid number");
                    return;
                }
            }
            if (usePoints <= 0) {
                JOptionPane.showMessageDialog(this, "No points used");
                return;
            }
            // Preview redemption: don't deduct points yet, only when checkout completes
            pendingPointsToUse = Math.min(usePoints, available);
            appliedDiscount = pendingPointsToUse / 100.0;
            computeTotals();
            JOptionPane.showMessageDialog(this, "Preview applied discount: $" + String.format("%.2f", appliedDiscount) + " (will consume " + pendingPointsToUse + " points on checkout)");
        });

        checkoutBtn.addActionListener(e -> {
            if (cartModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "Cart is empty");
                return;
            }
            double total = computeCartTotal();
            double beforeMembership = total - appliedDiscount;
            if (beforeMembership < 0) beforeMembership = 0;

            // Actually consume pending points now and apply their discount
            if (pendingPointsToUse > 0) {
                double actuallyApplied = customer.redeemPoints(pendingPointsToUse);
                // ensure appliedDiscount matches actual value (in case of race)
                appliedDiscount = actuallyApplied;
                pendingPointsToUse = 0;
            }

            double finalPrice = customer.buy(beforeMembership);

            StringBuilder sb = new StringBuilder();
            sb.append("Receipt:\n");
            for (int i = 0; i < cartModel.getRowCount(); i++) {
                Object priceObj = cartModel.getValueAt(i, 1);
                double price = (priceObj instanceof Number) ? ((Number) priceObj).doubleValue() : Double.parseDouble(priceObj.toString());
                sb.append(cartModel.getValueAt(i, 0)).append(" - $").append(String.format("%.2f", price)).append("\n");
            }
            sb.append("\nTotal: $").append(String.format("%.2f", total));
            sb.append("\nRedeemed Discount: $").append(String.format("%.2f", appliedDiscount));
            sb.append("\nFinal Price (after status discount): $").append(String.format("%.2f", finalPrice));
            sb.append("\nPoints: ").append(customer.getPoints());
            sb.append("\nStatus: ").append(customer.getStatus());

            JOptionPane.showMessageDialog(this, sb.toString());

            cartModel.setRowCount(0);
            appliedDiscount = 0.0;
            pendingPointsToUse = 0;
            computeTotals();

            FileManager.saveCustomers(store);
        });

        logoutBtn.addActionListener(e -> {
            FileManager.saveCustomers(store);
            frame.showLogin();
        });

        computeTotals();
    }

    private void refreshStoreTable(BookStore store) {
        storeModel.setRowCount(0);
        for (Book b : store.getBooks()) {
            storeModel.addRow(new Object[]{b.getName(), b.getPrice()});
        }
    }

    private double computeCartTotal() {
        double total = 0;
        for (int i = 0; i < cartModel.getRowCount(); i++) {
            Object priceObj = cartModel.getValueAt(i, 1);
            double price = (priceObj instanceof Number) ? ((Number) priceObj).doubleValue() : Double.parseDouble(priceObj.toString());
            total += price;
        }
        return total;
    }

    private void computeTotals() {
        double total = computeCartTotal();
        double discount = appliedDiscount;
        double after = total - discount;
        if (after < 0) after = 0;
        totalLabel.setText("Total: $" + String.format("%.2f", total));
        discountLabel.setText("Discount: $" + String.format("%.2f", discount));
        finalLabel.setText("Final: $" + String.format("%.2f", after));
        pointsLabel.setText("Points: " + customer.getPoints() + (pendingPointsToUse > 0 ? " (pending use: " + pendingPointsToUse + ")" : ""));
        statusLabel.setText("Status: " + customer.getStatus());
    }
}