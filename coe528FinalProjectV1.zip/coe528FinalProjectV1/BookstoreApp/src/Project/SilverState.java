package Project;

public class SilverState implements State_interface {

    @Override
    public double getDiscount(double total) {
        return 0;
    }

    @Override
    public int getPointsEarned(double total) {
        return (int)(total * 10);
    }

    @Override
    public String getStatus() {
        return "Silver";
    }
}