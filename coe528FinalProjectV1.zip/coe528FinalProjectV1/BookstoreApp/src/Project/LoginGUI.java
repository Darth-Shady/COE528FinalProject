package Project;

import javax.swing.*;
import java.awt.*;

public class LoginGUI extends JPanel {

    public LoginGUI(MainFrame frame, BookStore store) {
        setLayout(new GridLayout(3, 2));

        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JButton loginBtn = new JButton("Login");

        add(new JLabel("Username:"));
        add(userField);
        add(new JLabel("Password:"));
        add(passField);
        add(new JLabel());
        add(loginBtn);

        loginBtn.addActionListener(e -> {
            String username = userField.getText();
            String password = new String(passField.getPassword());

            if (username.equals("admin") && password.equals("admin")) {
                frame.showOwner();
            } else {
                Customer c = store.login(username, password);
                if (c != null) {
                    frame.showCustomer(c);
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid login");
                }
            }
        });
    }
}